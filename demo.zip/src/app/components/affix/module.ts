import { NzAffixModule } from 'ng-zorro-antd/affix';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzAnchorModule } from 'ng-zorro-antd/anchor';

export const moduleList = [ NzAffixModule, NzButtonModule, NzAnchorModule ];
