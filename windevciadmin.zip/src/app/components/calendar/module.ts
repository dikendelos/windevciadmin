import { NzCalendarModule } from 'ng-zorro-antd/calendar';
import { NzBadgeModule } from 'ng-zorro-antd/badge';
import { NzAlertModule } from 'ng-zorro-antd/alert';

export const moduleList = [ NzCalendarModule, NzBadgeModule, NzAlertModule ];
