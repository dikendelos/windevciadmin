import { NzListModule } from 'ng-zorro-antd/list';
import { NzCardModule } from 'ng-zorro-antd/card';
import { NzSkeletonModule } from 'ng-zorro-antd/skeleton';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzTypographyModule } from 'ng-zorro-antd/typography';
import { NzGridModule } from 'ng-zorro-antd/grid';

export const moduleList = [
  NzListModule,
  NzCardModule,
  NzSkeletonModule,
  NzPaginationModule,
  NzButtonModule,
  NzTypographyModule,
  NzGridModule
];
