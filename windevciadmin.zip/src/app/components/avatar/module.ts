import { NzAvatarModule } from 'ng-zorro-antd/avatar';
import { NzBadgeModule } from 'ng-zorro-antd/badge';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { CommonModule } from '@angular/common';

export const moduleList = [ CommonModule, NzAvatarModule, NzBadgeModule, NzButtonModule ];
