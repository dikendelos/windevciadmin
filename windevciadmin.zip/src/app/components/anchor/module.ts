import { NzAnchorModule } from 'ng-zorro-antd/anchor';

export const moduleList = [ NzAnchorModule ];
