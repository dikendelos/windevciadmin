import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzSliderModule } from 'ng-zorro-antd/slider';
import { NzDividerModule } from 'ng-zorro-antd/divider';

export const moduleList = [ NzGridModule, NzSliderModule, NzDividerModule ];
