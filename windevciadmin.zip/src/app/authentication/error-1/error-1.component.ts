import { Component } from '@angular/core'

@Component({
    templateUrl: './error-1.component.html'
})

export class Error1Component {
   
}    