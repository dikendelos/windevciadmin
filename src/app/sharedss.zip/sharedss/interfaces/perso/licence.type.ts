export interface Licence {
    id: number,
    libelle: string,
    description: string
}