export interface Produit {
    id: number,
    extrat_titre: string,
    nom_produit: string,
    description: string,
    licence_id: number
    lience: string
}