// import { Licence } from "../interfaces/perso/licence.type";
export interface Retour {
    status: number;
    contenu: any[];
    message: string
}